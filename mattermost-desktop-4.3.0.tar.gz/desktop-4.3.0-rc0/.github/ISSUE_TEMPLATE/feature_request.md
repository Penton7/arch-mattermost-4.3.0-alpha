---
name: Feature request
about: Suggest an idea for this project

---

Suggest features in the Mattermost feature idea forum so it can be discussed, upvoted and considered for a [help wanted ticket](https://docs.mattermost.com/process/help-wanted.html).

[https://mattermost.uservoice.com](https://mattermost.uservoice.com/forums/306457-general?category_id=159795)

You get 10 votes in the feature idea forum, and each one influences the future of the project.
