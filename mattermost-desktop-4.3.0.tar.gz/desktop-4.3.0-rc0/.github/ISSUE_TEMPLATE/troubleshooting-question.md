---
name: Troubleshooting question
about: Ask a question to solve installation and configuration issues 

---

For troubleshooting, see [https://www.mattermost.org/troubleshoot/](https://www.mattermost.org/troubleshoot/).
